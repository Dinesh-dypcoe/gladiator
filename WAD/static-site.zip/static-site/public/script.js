console.log("Hello from JavaScript!");
